/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a1;

/**
 *
 * @author tokol
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Base class
class Artist {
    private String name;
    private String genre;

    public Artist(String name, String genre) {
        this.name = name;
        this.genre = genre;
    }

    public String getName() {
        return name;
    }

    public String getGenre() {
        return genre;
    }
}

// Derived class
class RankedArtist extends Artist {
    private int rank;
    private String recordLabel;
    private String bestAlbum;

    public RankedArtist(String name, String genre, int rank, String recordLabel, String bestAlbum) {
        super(name, genre);
        this.rank = rank;
        this.recordLabel = recordLabel;
        this.bestAlbum = bestAlbum;
    }

    public int getRank() {
        return rank;
    }

    public String getRecordLabel() {
        return recordLabel;
    }

    public String getBestAlbum() {
        return bestAlbum;
    }

    public void displayInfo() {
        System.out.println("Rank #" + getRank() + ": " + getName() + " (" + getGenre() +
                ") - Label: " + getRecordLabel() + " | Best Album: " + getBestAlbum());
    }
}

// Main class
public class ArtistRankingApp {
    public static void main(String[] args) {
        
        // 2D Array for holding artists of 2 record labels (labels are represented in the first dimension)
        String[][] labels = {
            {"Opium", "Homixide Gang", "Ken Carson", "Destroy Lonely", "Playboi Carti"},
            {"Cactus Jack", "Travis Scott", "Sheck Wes", "SoFaygo", "Don Toliver"}
        };

        // 3D Array for holding artist details: [label index][artist index][attribute]
        int numLabels = 2;
        int maxArtists = 5; // Assuming the max number of artists per label
        String[][][] artistDetails = new String[numLabels][maxArtists][4]; // [label index][artist index][rank, name, genre, bestAlbum]

        // Populating artist details for Opium label
        artistDetails[0][0] = new String[]{"2", "Homixide Gang", "Hip-Hop", "Homixide Gang"};
        artistDetails[0][1] = new String[]{"4", "Ken Carson", "Hip-Hop", "A Great Chaos"};
        artistDetails[0][2] = new String[]{"1", "Destroy Lonely", "Hip-Hop", "If Looks Could Kill"};
        artistDetails[0][3] = new String[]{"3", "Playboi Carti", "Hip-Hop", "Die Lit"};

        // Populating artist details for Cactus Jack label
        artistDetails[1][0] = new String[]{"1", "Travis Scott", "Hip-Hop", "Astroworld"};
        artistDetails[1][1] = new String[]{"3", "Sheck Wes", "Hip-Hop", "Mudboy"};
        artistDetails[1][2] = new String[]{"4", "SoFaygo", "Hip-Hop", "Pink Hearted"};
        artistDetails[1][3] = new String[]{"2", "Don Toliver", "Hip-Hop", "Heaven Or Hell"};

        // Use an ArrayList to hold all artists
        List<RankedArtist> allArtistsList = new ArrayList<>();

        // Populate the list with artist details
        for (int i = 0; i < numLabels; i++) {
            for (int j = 0; j < maxArtists; j++) {
                if (artistDetails[i][j][0] != null) {
                    String rank = artistDetails[i][j][0];
                    String name = artistDetails[i][j][1];
                    String genre = artistDetails[i][j][2];
                    String bestAlbum = artistDetails[i][j][3];
                    allArtistsList.add(new RankedArtist(name, genre, Integer.parseInt(rank), labels[i][0], bestAlbum));
                }
            }
        }

        // Convert ArrayList to array and sort all artists based on their rank
        RankedArtist[] allArtists = allArtistsList.toArray(new RankedArtist[0]);
        Arrays.sort(allArtists, (a, b) -> Integer.compare(a.getRank(), b.getRank()));

        // Display sorted artists according to their rank
        System.out.println("Top Artists from both Labels:");
        for (RankedArtist artist : allArtists) {
            artist.displayInfo();
        }
    }
}
