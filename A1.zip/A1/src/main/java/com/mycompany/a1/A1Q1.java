/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.a1;

/**
 *
 * @author tokol
 */
import java.util.ArrayList;
import java.util.Scanner;

// Class to save student details
class Student {
    String studentId;
    String name;
    int age;
    String email;
    String courseCode;
    int index; // Added index field
    
    // Constructor to store student details
    public Student(String studentId, String name, int age, String email, String courseCode, int index) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.email = email;
        this.courseCode = courseCode;
        this.index = index; // Initialize index
    }

    @Override
    public String toString() {
        return "Index: " + index +
                "\nStudent ID: " + studentId +
                "\nName: " + name +
                "\nAge: " + age +
                "\nEmail: " + email +
                "\nCourse Code: " + courseCode;
    }
}

// Main class
public class A1Q1 {
    // Single array for student details
    private static ArrayList<Student> studentList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void Menu() {
        int choice;

        do {
            // Display menu options
            System.out.println("Please select one of the following menu items: ");
            System.out.println("1. Capture a new student.");
            System.out.println("2. Search for a student.");
            System.out.println("3. Delete a student.");
            System.out.println("4. Print student report.");
            System.out.println("5. Exit Application.");
            
            // Read user input
            choice = scanner.nextInt();
            scanner.nextLine();

            // Process user choice
            switch (choice) {
                case 1:
                    option1();
                    break;
                case 2:
                    option2();
                    break;
                case 3:
                    option3();
                    break;
                case 4:
                    option4();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
            
        } while (choice != 5);
    }

    public static void main(String[] args) {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*************************************************");

        String userInput;

        do {
            System.out.println("Enter (1) to launch menu or any other key to exit:");
            userInput = scanner.nextLine();

            if ("1".equals(userInput)) {
                Menu();
            } else {
                System.out.println("Exiting application.");
                break;
            }
        } while (!userInput.equals("1"));

        scanner.close();
    }

    // Method logic for option 1
    private static void option1() {
        System.out.println("You selected Option 1: Capture a new student.");
        System.out.println("************************************************");
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("*************************************************");
        
        // Get the index for the new student
        int index = studentList.size() + 1;
        
        // Capture student details
        System.out.print("Enter Student ID: ");
        String studentId = scanner.nextLine();
        
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter Age: ");
        int age = scanner.nextInt(); 
        scanner.nextLine();
        
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        
        System.out.print("Enter Course Code: ");
        String courseCode = scanner.nextLine();
        
        // Create a new student object with index and add it to the list
        Student newStudent = new Student(studentId, name, age, email, courseCode, index);
        studentList.add(newStudent);
        
        // Display the captured student details
        System.out.println("\nStudent captured successfully:");
        System.out.println("--------------------------------------------------");
        System.out.println("STUDENT " + index);
        System.out.println("--------------------------------------------------");
        System.out.println("STUDENT ID: " + studentId);
        System.out.println("STUDENT NAME: " + name);
        System.out.println("STUDENT AGE: " + age);
        System.out.println("STUDENT EMAIL: " + email);
        System.out.println("STUDENT COURSE: " + courseCode);
        System.out.println("--------------------------------------------------");
        
        promptToContinue();
    }

    private static void option2() {
        System.out.println("You selected Option 2: Search for a student.");

        // Prompt the user for the student ID to search
        System.out.print("Enter Student ID to search: ");
        String searchId = scanner.nextLine();
        
        // Search for student in the ArrayList
        Student foundStudent = null;
        for (Student student : studentList) {
            if (student.studentId.equals(searchId)) {
                foundStudent = student;
                break;
            }
        }
        
        // Display the result
        if (foundStudent != null) {
            System.out.println("\nStudent found:");
            System.out.println("--------------------------------------------------");
            System.out.println("STUDENT " + foundStudent.index);
            System.out.println("--------------------------------------------------");
            System.out.println("STUDENT ID: " + foundStudent.studentId);
            System.out.println("STUDENT NAME: " + foundStudent.name);
            System.out.println("STUDENT AGE: " + foundStudent.age);
            System.out.println("STUDENT EMAIL: " + foundStudent.email);
            System.out.println("STUDENT COURSE: " + foundStudent.courseCode);
            System.out.println("--------------------------------------------------");
        } else {
            System.out.println("Student with ID " + searchId + " was not found.");
        }
        
        promptToContinue();
    }

    private static void option3() {
        System.out.println("You selected Option 3: Delete a student.");
        
        // Prompt the user for the student ID to delete
        System.out.print("Enter Student ID to delete: ");
        String studentIdToDelete = scanner.nextLine();

        // Search for the student and remove from the list
        boolean removed = false;
        for (Student student : studentList) {
            if (student.studentId.equals(studentIdToDelete)) {
                studentList.remove(student);
                // Reassign indexes
                reassignIndexes();
                System.out.println("Student with ID " + studentIdToDelete + " has been deleted.");
                removed = true;
                break;
            }
        }

        if (!removed) {
            System.out.println("Student with ID " + studentIdToDelete + " was not found.");
        }
        
        promptToContinue();
    }

    private static void reassignIndexes() {
        // Reassign indexes after deletion
        for (int i = 0; i < studentList.size(); i++) {
            studentList.get(i).index = i + 1;
        }
    }

    private static void option4() {
        System.out.println("You have selected Option 4: Print student report.");
        
        if (studentList.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            for (Student student : studentList) {
                System.out.println("\n--------------------------------------------------");
                System.out.println("STUDENT " + student.index);
                System.out.println("--------------------------------------------------");
                System.out.println("STUDENT ID: " + student.studentId);
                System.out.println("STUDENT NAME: " + student.name);
                System.out.println("STUDENT AGE: " + student.age);
                System.out.println("STUDENT EMAIL: " + student.email);
                System.out.println("STUDENT COURSE: " + student.courseCode);
                System.out.println("--------------------------------------------------");
            }
        }
        
        promptToContinue();
    }

    private static void promptToContinue() {
        System.out.println("\nEnter (1) to launch menu or any other key to exit:");
        String userInput = scanner.nextLine();
        if (!"1".equals(userInput)) {
            System.out.println("Exiting application.");
            System.exit(0);
        }
    }
}

